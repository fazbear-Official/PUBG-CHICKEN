import { githubDB } from "../../lib/database.js";
import crypto from "crypto";

const USERS_PATH = "database/users.json";

export default async function handler(req, res) {

  // السماح فقط POST
  if (req.method !== "POST") {
    return res.status(405).json({
      error: "Method not allowed"
    });
  }

  const { email, password } = req.body;

  if (!email || !password) {
    return res.status(400).json({
      error: "Email and password required"
    });
  }

  try {

    // ===== قراءة قاعدة المستخدمين =====
    let raw = await githubDB.readFile(USERS_PATH);
    let data;

    try {
      data = typeof raw === "string" ? JSON.parse(raw) : raw;
    } catch {
      return res.status(500).json({
        error: "Users database corrupted"
      });
    }

    if (!data || !Array.isArray(data.users)) {
      return res.status(401).json({
        error: "Invalid credentials"
      });
    }

    // ===== تشفير الباسورد =====
    const hashedPassword = crypto
      .createHash("sha256")
      .update(password)
      .digest("hex");

    // ===== البحث عن المستخدم =====
    const userIndex = data.users.findIndex(
      u => u.email === email && u.password === hashedPassword
    );

    if (userIndex === -1) {
      return res.status(401).json({
        error: "Invalid credentials"
      });
    }

    const user = data.users[userIndex];

    // ===== تحديث آخر تسجيل دخول =====
    user.lastLogin = Date.now();
    data.users[userIndex] = user;

    await githubDB.updateFile(
      USERS_PATH,
      JSON.stringify(data, null, 2),
      "update last login"
    );

    // ===== إرسال البيانات للفرونت =====
    return res.status(200).json({
      success: true,
      user: {
        id: user.id,
        username: user.username,
        email: user.email,
        phone: user.phone || "",   // مهم علشان يظهر الهاتف
        lastLogin: user.lastLogin
      }
    });

  } catch (err) {

    console.error("LOGIN ERROR:", err);

    return res.status(500).json({
      error: "Server error"
    });
  }

}