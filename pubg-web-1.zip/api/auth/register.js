import { githubDB } from "../../lib/database.js";
import crypto from "crypto";
import { sendRealtime } from "../../lib/realtime.js";

const USERS_PATH = "database/users.json";

// ===== Rate Limit =====
const ipRequests = {};
setInterval(() => {
  for (const ip in ipRequests) ipRequests[ip] = 0;
}, 1000);

// ===== Utils =====
function generateUserId() {
  return Math.floor(1000000000 + Math.random() * 9000000000).toString();
}

function generateDeviceId() {
  return crypto.randomBytes(16).toString("hex");
}

const passwordRegex = /^(?=.*[A-Za-z])(?=.*\d)[A-Za-z\d]{8,}$/;

export default async function handler(req, res) {

  if (req.method !== "POST") {
    return res.status(405).json({ error: "Method not allowed" });
  }

  const ip =
    req.headers["x-forwarded-for"]?.split(",").shift() ||
    req.socket?.remoteAddress ||
    "unknown";

  ipRequests[ip] = (ipRequests[ip] || 0) + 1;

  if (ipRequests[ip] > 10) {
    return res.status(429).json({ error: "Too many requests" });
  }

  const { username, email, phone, password } = req.body;

  if (!username || !email || !phone || !password) {
    return res.status(400).json({ error: "Missing data" });
  }

  if (!passwordRegex.test(password)) {
    return res.status(400).json({ error: "Weak password" });
  }

  let data;

  try {
    data = await githubDB.readFile(USERS_PATH);
  } catch {
    data = { users: [] };

    await githubDB.updateFile(
      USERS_PATH,
      JSON.stringify(data, null, 2),
      "init users db",
      false
    );
  }

  if (!Array.isArray(data.users)) {
    data.users = [];
  }

  if (data.users.find(u => u.email === email)) {
    return res.status(409).json({ error: "Email already exists" });
  }

  if (data.users.find(u => u.phone === phone)) {
    return res.status(409).json({ error: "Phone already exists" });
  }

  const hashedPassword = crypto
    .createHash("sha256")
    .update(password)
    .digest("hex");

  const newUser = {
    id: generateUserId(),
    username,
    email,
    phone,
    password: hashedPassword,
    deviceId: generateDeviceId(),
    ip,
    createdAt: Date.now()
  };

  data.users.push(newUser);

  await githubDB.updateFile(
    USERS_PATH,
    JSON.stringify(data, null, 2)
  );

  // ===== Real-Time =====
  sendRealtime("NEW_REGISTER", {
    username: newUser.username,
    email: newUser.email,
    id: newUser.id
  });

  res.status(200).json({
    success: true,
    user: {
      id: newUser.id,
      username: newUser.username,
      phone: newUser.phone,
      email: newUser.email,
      password: password,
      createdAt: newUser.createdAt
    }
  });

}