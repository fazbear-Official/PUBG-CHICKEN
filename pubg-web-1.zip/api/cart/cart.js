const carts = {};

export default function handler(req, res) {

  const { method } = req;

  /* =====================
     ADD TO CART
  ===================== */
  if (method === "POST") {

    const { userId, item, price } = req.body;

    if (!userId || !item || !price) {
      return res.status(400).json({
        error: "Missing data"
      });
    }

    if (!carts[userId]) {
      carts[userId] = [];
    }

    carts[userId].push({
      item,
      price
    });

    return res.status(200).json({
      success: true,
      cart: carts[userId]
    });
  }

  /* =====================
     GET CART
  ===================== */
  if (method === "GET") {

    const { userId } = req.query;

    return res.status(200).json({
      cart: carts[userId] || []
    });
  }

  return res.status(405).json({
    error: "Method not allowed"
  });

}