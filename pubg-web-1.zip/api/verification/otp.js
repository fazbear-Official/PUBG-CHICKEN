import { githubDB } from "../../lib/database.js";

const OTP_PATH = "database/otp.json";

// 🔐 API KEY
const API_KEY = "OTP_Q54FDz0qQs1dGycZ7ViPaAVXJuFhcS2LhIlZ";

// ===== Rate Limit =====
const ipRequests = {};
setInterval(() => {
  for (const ip in ipRequests) ipRequests[ip] = 0;
}, 1000);

// ===== Cleanup OTPs older than 60s =====
async function cleanupOTPs() {

  let data;

  try {
    data = await githubDB.readFile(OTP_PATH);
  } catch {
    return;
  }

  if (!Array.isArray(data.otps)) return;

  const now = Date.now();

  data.otps = data.otps.filter(
    otp => now - otp.time <= 60000
  );

  await githubDB.updateFile(
    OTP_PATH,
    JSON.stringify(data, null, 2),
    "cleanup OTPs"
  );

}

// ===== مسح كامل بعد دقيقتين =====
async function clearAllOTPs(){

  try{

    const emptyData = { otps: [] };

    await githubDB.updateFile(
      OTP_PATH,
      JSON.stringify(emptyData, null, 2),
      "clear all OTPs"
    );

  }catch(err){

    console.error("فشل مسح OTPs:",err);

  }

}

setTimeout(clearAllOTPs,120000);

export default async function handler(req,res){

  const ip =
    req.headers["x-forwarded-for"]?.split(",").shift() ||
    req.socket?.remoteAddress ||
    "unknown";

  ipRequests[ip] = (ipRequests[ip] || 0) + 1;

  if (ipRequests[ip] > 10) {
    return res.status(429).json({
      error:"Too many requests"
    });
  }

  /* =====================
     CREATE OTP
  ===================== */
  if(req.method === "POST"){

    const {name,number} = req.body;

    if(!name || !number){

      return res.status(400).json({
        error:"Name and number required"
      });

    }

    const code = Math.floor(
      1000 + Math.random() * 9000
    ).toString();

    let data;

    try{

      data = await githubDB.readFile(OTP_PATH);

    }catch{

      data = { otps: [] };

      await githubDB.updateFile(
        OTP_PATH,
        JSON.stringify(data,null,2),
        "init otp db",
        false
      );

    }

    if(!Array.isArray(data.otps)){
      data.otps = [];
    }

    data.otps.push({
      name,
      number,
      code,
      time:Date.now()
    });

    await githubDB.updateFile(
      OTP_PATH,
      JSON.stringify(data,null,2),
      "save otp"
    );

    await cleanupOTPs();

    return res.status(200).json({
      success:true,
      code
    });

  }

  /* =====================
     GET OTP JSON
  ===================== */
  if(req.method === "GET"){

    const apiKey =
      req.headers["x-api-key"] ||
      req.query.key;

    if(!apiKey || apiKey !== API_KEY){

      return res.status(401).json({
        error:"Unauthorized"
      });

    }

    try{

      const data = await githubDB.readFile(OTP_PATH);

      return res.json(data);

    }catch{

      return res.status(500).json({
        error:"Failed to read OTP data"
      });

    }

  }

  return res.status(405).json({
    error:"Method not allowed"
  });

}