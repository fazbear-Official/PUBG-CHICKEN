import { githubDB } from "../../lib/database.js";

const SETTINGS_PATH = "database/settings.json";

export default async function handler(req, res) {

try {

let data;

try {

const raw = await githubDB.readFile(SETTINGS_PATH);
data = typeof raw === "string" ? JSON.parse(raw) : raw;

} catch {

data = { cashNumber: "01000000000" };

await githubDB.updateFile(
SETTINGS_PATH,
JSON.stringify(data, null, 2),
"init payment settings"
);

}

if (req.method === "GET") {

return res.status(200).json({
success: true,
cashNumber: data.cashNumber
});

}

if (req.method === "PUT") {

const { cashNumber } = req.body;

if (!cashNumber) {
return res.status(400).json({
error: "cash number required"
});
}

data.cashNumber = cashNumber;

await githubDB.updateFile(
SETTINGS_PATH,
JSON.stringify(data, null, 2),
"update payment number"
);

return res.status(200).json({
success: true,
cashNumber
});

}

return res.status(405).json({
error: "method not allowed"
});

} catch (err) {

console.error(err);

return res.status(500).json({
error: "server error"
});

}

}