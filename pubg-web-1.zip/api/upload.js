import formidable from "formidable";
import fs from "fs";
import fetch from "node-fetch";
import FormData from "form-data";

export const config = {
  api: {
    bodyParser: false
  }
};

export default async function handler(req, res) {

  if (req.method !== "POST") {
    return res.status(405).json({ error: "Method not allowed" });
  }

  try {

    const form = new formidable.IncomingForm();

    form.parse(req, async (err, fields, files) => {

      if (err) {
        return res.status(500).json({ error: "Upload parse error" });
      }

      const file = files.file;

      if (!file) {
        return res.status(400).json({ error: "No file uploaded" });
      }

      const fileStream = fs.createReadStream(file.filepath);

      const uploadForm = new FormData();
      uploadForm.append("reqtype", "fileupload");
      uploadForm.append("fileToUpload", fileStream);

      const upload = await fetch("https://catbox.moe/user/api.php", {
        method: "POST",
        body: uploadForm
      });

      const text = await upload.text();

      if (!text.startsWith("https://")) {
        return res.status(500).json({ error: "Upload failed" });
      }

      return res.json({
        success: true,
        url: text
      });

    });

  } catch (err) {

    console.error(err);

    return res.status(500).json({
      error: "Server error"
    });

  }

}