import { githubDB } from "../../lib/database.js";

const ORDER_PATH = "database/orders.json";
const COUPON_PATH = "database/coupons.json";

async function readOrders() {
  try {
    const raw = await githubDB.readFile(ORDER_PATH);
    const data = typeof raw === "string" ? JSON.parse(raw) : raw;
    if (!data.orders) data.orders = [];
    return data;
  } catch {
    return { orders: [] };
  }
}

async function saveOrders(data) {
  await githubDB.updateFile(
    ORDER_PATH,
    JSON.stringify(data, null, 2),
    "update orders"
  );
}

async function readCoupons() {
  try {
    const raw = await githubDB.readFile(COUPON_PATH);
    const data = typeof raw === "string" ? JSON.parse(raw) : raw;
    if (!data.coupons) data.coupons = [];
    return data;
  } catch {
    return { coupons: [] };
  }
}

async function saveCoupons(data) {
  await githubDB.updateFile(
    COUPON_PATH,
    JSON.stringify(data, null, 2),
    "update coupons"
  );
}

function calculateTotal(items) {
  let total = 0;

  items.forEach(i => {
    total += i.price * (i.qty || 1);
  });

  return total;
}

export default async function handler(req, res) {

  const { method } = req;
  const action = req.query.action;
  const id = req.query.id;

  const ordersData = await readOrders();

  // =====================
  // CREATE ORDER
  // =====================
  if (method === "POST" && action === "create") {

    const { userId, username, email, phone, items } = req.body;

    if (!userId || !items) {
      return res.status(400).json({
        error: "Missing data"
      });
    }

    const total = calculateTotal(items);

    const order = {
      id: Date.now().toString(),
      userId,
      username,
      email,
      phone,
      items,
      total,
      status: "pending",
      proof: null,
      createdAt: Date.now()
    };

    ordersData.orders.push(order);

    await saveOrders(ordersData);

    return res.status(200).json({
      success: true,
      orderId: order.id
    });
  }

  // =====================
// UPLOAD PAYMENT PROOF
// =====================
if (method === "POST" && action === "upload-proof") {

  const { orderId, proof } = req.body;

  if (!orderId || !proof) {
    return res.status(400).json({
      error: "missing data"
    });
  }

  const order = ordersData.orders.find(o => o.id === orderId);

  if (!order) {
    return res.status(404).json({
      error: "order not found"
    });
  }

  order.proof = proof;

  await saveOrders(ordersData);

  return res.json({
    success: true,
    order
  });
}

  // =====================
  // GET USER ORDERS
  // =====================
  if (method === "GET" && req.query.userId) {

    const orders = ordersData.orders.filter(
      o => o.userId === req.query.userId
    );

    return res.status(200).json({
      orders
    });
  }

  // =====================
  // GET ALL ORDERS (ADMIN)
  // =====================
  if (method === "GET" && action === "all") {

    return res.json({
      orders: ordersData.orders
    });
  }

  // =====================
  // ACCEPT ORDER
  // =====================
  if (method === "POST" && action === "accept") {

    const order = ordersData.orders.find(
      o => o.id === id
    );

    if (!order) {
      return res.status(404).json({
        error: "order not found"
      });
    }

    order.status = "accepted";

    await saveOrders(ordersData);

    return res.json({
      success: true,
      order
    });
  }

  // =====================
  // DELIVER ORDER
  // =====================
  if (method === "POST" && action === "deliver") {

    const order = ordersData.orders.find(
      o => o.id === id
    );

    if (!order) {
      return res.status(404).json({
        error: "order not found"
      });
    }

    order.status = "delivered";

    await saveOrders(ordersData);

    return res.json({
      success: true,
      order
    });
  }

  // =====================
  // REJECT ORDER
  // =====================
  if (method === "POST" && action === "reject") {

    const order = ordersData.orders.find(
      o => o.id === id
    );

    if (!order) {
      return res.status(404).json({
        error: "order not found"
      });
    }

    order.status = "rejected";

    await saveOrders(ordersData);

    return res.json({
      success: true,
      order
    });
  }

  // =====================
  // CREATE COUPON
  // =====================
  if (method === "POST" && action === "create-coupon") {

    const { code, percent, uses } = req.body;

    const data = await readCoupons();

    const coupon = {
      code,
      percent,
      uses
    };

    data.coupons.push(coupon);

    await saveCoupons(data);

    return res.json({
      success: true,
      coupon
    });
  }

  // =====================
  // GET COUPONS
  // =====================
  if (method === "GET" && action === "coupons") {

    const data = await readCoupons();

    return res.json({
      coupons: data.coupons
    });
  }

  return res.status(400).json({
    error: "Invalid request"
  });
}