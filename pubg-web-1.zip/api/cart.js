import { githubDB } from "../lib/database.js";

const CART_PATH = "database/carts.json";

export default async function handler(req, res) {

  let data;

  try {
    const raw = await githubDB.readFile(CART_PATH);
    data = typeof raw === "string" ? JSON.parse(raw) : raw;
  } catch {
    data = { carts: {} };
  }

  if (!data.carts) data.carts = {};

  const { method } = req;
  const { action } = req.query;

  /* ================= ADD ================= */

  if (method === "POST" && action === "add") {

    const { userId, id, name, price, image } = req.body;

    if (!data.carts[userId]) data.carts[userId] = [];

    const cart = data.carts[userId];

    const existing = cart.find(i => i.id == id);

    if (existing) {
      existing.qty += 1;
    } else {
      cart.push({
        id,
        name,
        price,
        image,
        qty: 1
      });
    }

    await githubDB.updateFile(
      CART_PATH,
      JSON.stringify(data, null, 2),
      "add to cart"
    );

    return res.json({ success: true, items: cart });
  }

  /* ================= INCREASE ================= */

  if (method === "POST" && action === "increase") {

    const { userId, index } = req.body;

    if (data.carts[userId] && data.carts[userId][index]) {
      data.carts[userId][index].qty += 1;
    }

    await githubDB.updateFile(
      CART_PATH,
      JSON.stringify(data, null, 2),
      "increase qty"
    );

    return res.json({ success: true });
  }

  /* ================= DECREASE ================= */

  if (method === "POST" && action === "decrease") {

    const { userId, index } = req.body;

    if (data.carts[userId] && data.carts[userId][index]) {

      if (data.carts[userId][index].qty > 1) {
        data.carts[userId][index].qty -= 1;
      }

    }

    await githubDB.updateFile(
      CART_PATH,
      JSON.stringify(data, null, 2),
      "decrease qty"
    );

    return res.json({ success: true });
  }

  /* ================= REMOVE ================= */

  if (method === "POST" && action === "remove") {

    const { userId, index } = req.body;

    if (data.carts[userId]) {
      data.carts[userId].splice(index, 1);
    }

    await githubDB.updateFile(
      CART_PATH,
      JSON.stringify(data, null, 2),
      "remove item"
    );

    return res.json({ success: true });
  }

  /* ================= CLEAR ================= */

  if (method === "POST" && action === "clear") {

    const { userId } = req.body;

    data.carts[userId] = [];

    await githubDB.updateFile(
      CART_PATH,
      JSON.stringify(data, null, 2),
      "clear cart"
    );

    return res.json({ success: true });
  }

  /* ================= GET ================= */

  if (method === "GET") {

    const { userId } = req.query;

    return res.json({
      items: data.carts[userId] || []
    });
  }

  return res.status(405).json({
    error: "Method not allowed"
  });

}