import fs from "fs";

const FILE = process.cwd() + "/database/users.json";

export function addPoint(userId) {

 const users = JSON.parse(fs.readFileSync(FILE));

 const user = users.users.find(u => u.id === userId);

 if (!user) return;

 // لو لم تكن موجودة ننشئها
 if (!user.points) user.points = 0;
 if (!user.spinTokens) user.spinTokens = 0;

 user.points += 1;

 // كل 10 نقاط = لفة عجلة
 if (user.points >= 10) {

  user.points = 0;

  user.spinTokens += 1;

 }

 fs.writeFileSync(
  FILE,
  JSON.stringify(users, null, 2)
 );

}