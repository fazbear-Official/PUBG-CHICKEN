import fs from "fs";

const FILE = process.cwd() + "/database/rewards.json";

export default function handler(req, res){

 if(req.method !== "POST"){
  return res.status(405).json({
   error:"Method not allowed"
  });
 }

 const { name, type } = req.body;

 const data = JSON.parse(fs.readFileSync(FILE));

 const reward = {

  id: Date.now().toString(),
  name,
  type

 };

 data.rewards.push(reward);

 fs.writeFileSync(
  FILE,
  JSON.stringify(data, null, 2)
 );

 res.status(200).json({
  success: true,
  reward
 });

}