import { githubDB } from "../../lib/database.js";

const MENU_PATH = "database/menu.json";

export default async function handler(req, res) {

  try {

    let data;

    /* ======================
       LOAD DATABASE
    ====================== */

    try {

      const raw = await githubDB.readFile(MENU_PATH);
      data = typeof raw === "string" ? JSON.parse(raw) : raw;

    } catch {

      data = { items: [] };

      await githubDB.updateFile(
        MENU_PATH,
        JSON.stringify(data, null, 2),
        "init menu database"
      );

    }

    if (!Array.isArray(data.items)) {
      data.items = [];
    }

    const { method } = req;

    /* ======================
       GET MENU
    ====================== */

    if (method === "GET") {

      let items = [...data.items];

      const {
        category,
        search,
        sort,
        limit,
        available,
        offers
      } = req.query;

      /* CATEGORY */

      if (category) {
        items = items.filter(
          i => (i.category || "") === category
        );
      }

      /* SEARCH */

      if (search) {
        items = items.filter(i =>
          (i.name || "")
            .toLowerCase()
            .includes(search.toLowerCase())
        );
      }

      /* AVAILABLE */

      if (available) {
        items = items.filter(
          i => String(i.available) === available
        );
      }

      /* OFFERS ONLY */

      if (offers === "true") {

        items = items.filter(i =>
          (i.onOffer === true) ||
          (i.discount && i.discount > 0)
        );

      }

      /* SORT */

      if (sort === "price") {

        items = items.sort(
          (a, b) =>
            (a.finalPrice || a.price) -
            (b.finalPrice || b.price)
        );

      }

      if (sort === "-price") {

        items = items.sort(
          (a, b) =>
            (b.finalPrice || b.price) -
            (a.finalPrice || a.price)
        );

      }

      /* MOST POPULAR */

      if (sort === "popular") {

        items = items.sort((a, b) => {

          const aCount = a.orders || 0;
          const bCount = b.orders || 0;

          return bCount - aCount;

        });

      }

      /* LIMIT */

      if (limit) {
        items = items.slice(0, Number(limit));
      }

      return res.status(200).json({
        success: true,
        total: items.length,
        items
      });

    }

    /* ======================
       ADD ITEM
    ====================== */

    if (method === "POST") {

      const {
        name,
        ingredients,
        price,
        image,
        category,
        discount,
        available
      } = req.body;

      if (!name || !price) {

        return res.status(400).json({
          error: "Missing data"
        });

      }

      const priceNumber = Number(price);
      const discountNumber = Number(discount || 0);

      const item = {

        id: Date.now().toString(),

        name,

        ingredients: ingredients || "",

        price: priceNumber,

        discount: discountNumber,

        finalPrice: priceNumber - discountNumber,

        onOffer: discountNumber > 0,

        image: image || "",

        category: category || "عام",

        available: available !== false,

        orders: 0, // مهم للـ popular

        createdAt: Date.now()

      };

      data.items.push(item);

      await githubDB.updateFile(
        MENU_PATH,
        JSON.stringify(data, null, 2),
        "add menu item"
      );

      return res.status(200).json({
        success: true,
        item
      });

    }

    /* ======================
       UPDATE ITEM
    ====================== */

    if (method === "PUT") {

      const {
        id,
        name,
        ingredients,
        price,
        discount,
        image,
        category,
        available
      } = req.body;

      if (!id) {

        return res.status(400).json({
          error: "Missing item id"
        });

      }

      const index = data.items.findIndex(
        i => i.id === id
      );

      if (index === -1) {

        return res.status(404).json({
          error: "Item not found"
        });

      }

      const item = data.items[index];

      if (name !== undefined) item.name = name;
      if (ingredients !== undefined) item.ingredients = ingredients;
      if (price !== undefined) item.price = Number(price);
      if (discount !== undefined) item.discount = Number(discount);
      if (image !== undefined) item.image = image;
      if (category !== undefined) item.category = category;
      if (available !== undefined) item.available = available;

      /* RECALCULATE PRICE */

      item.discount = item.discount || 0;

      item.finalPrice = item.price - item.discount;

      item.onOffer = item.discount > 0;

      data.items[index] = item;

      await githubDB.updateFile(
        MENU_PATH,
        JSON.stringify(data, null, 2),
        "update menu item"
      );

      return res.status(200).json({
        success: true,
        item
      });

    }

    /* ======================
       DELETE ITEM
    ====================== */

    if (method === "DELETE") {

      const { id } = req.query;

      if (!id) {

        return res.status(400).json({
          error: "Missing item id"
        });

      }

      const index = data.items.findIndex(
        i => i.id === id
      );

      if (index === -1) {

        return res.status(404).json({
          error: "Item not found"
        });

      }

      const deleted = data.items.splice(index, 1)[0];

      await githubDB.updateFile(
        MENU_PATH,
        JSON.stringify(data, null, 2),
        "delete menu item"
      );

      return res.status(200).json({
        success: true,
        deleted
      });

    }

    return res.status(405).json({
      error: "Method not allowed"
    });

  } catch (err) {

    console.error("Menu API error:", err);

    return res.status(500).json({
      error: "Server error"
    });

  }

}