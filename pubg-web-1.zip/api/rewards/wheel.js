import fs from "fs";

const USERS_FILE = process.cwd() + "/database/users.json";
const REWARDS_FILE = process.cwd() + "/database/rewards.json";

function spin(rewards) {
  const random = Math.floor(Math.random() * rewards.length);
  return rewards[random];
}

export default function handler(req, res) {

  if (req.method !== "POST") {
    return res.status(405).json({
      error: "Method not allowed"
    });
  }

  const { userId } = req.body;

  const users = JSON.parse(fs.readFileSync(USERS_FILE));
  const rewardsData = JSON.parse(fs.readFileSync(REWARDS_FILE));

  const user = users.users.find(u => u.id === userId);

  if (!user) {
    return res.status(404).json({
      error: "User not found"
    });
  }

  if (!user.spinTokens || user.spinTokens <= 0) {
    return res.json({
      error: "لا يوجد لفات متاحة"
    });
  }

  const reward = spin(rewardsData.rewards);

  user.spinTokens -= 1;

  fs.writeFileSync(
    USERS_FILE,
    JSON.stringify(users, null, 2)
  );

  res.status(200).json({
    success: true,
    reward
  });

}